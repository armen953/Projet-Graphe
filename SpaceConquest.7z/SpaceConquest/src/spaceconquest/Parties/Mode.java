/*
 * Différents modes de jeu
 */
package spaceconquest.Parties;

/**
 *
 * @author simonetma
 */
public enum Mode {
    manuel,
    automatique;
}
