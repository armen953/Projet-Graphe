/*
 * Race jouable
 */
package spaceconquest.Race;

/**
 *
 * @author simonetma
 */
public enum Race {
    Zombie,
    Licorne;
}
